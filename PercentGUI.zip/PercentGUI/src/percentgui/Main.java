// Spencer Payne 4/30/2022
package percentgui;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application {

    // initialize variables
    float input = 0;
    float output = 0;
    TextField tb;
    Text result;

    @Override
    public void start(Stage primaryStage) {
        // Create gridpane
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(5);
        grid.setHgap(5);

        // Create text field
        tb = new TextField();
        grid.getChildren().add(tb);
        GridPane.setConstraints(tb, 1, 0);

        // Create button
        Button send = new Button("Convert");
        grid.getChildren().add(send);
        send.setPrefWidth(100);
        GridPane.setConstraints(send, 2,0);

        // Create text field for result
        result = new Text("");
        result.setFont((Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 24)));
        grid.getChildren().add(result);
        GridPane.setConstraints(result, 1, 3);

        // Create action for button press
        send.setOnAction(e -> {
            Float value1 = Float.parseFloat(tb.getText());
            value1 = value1 * 100;
            System.out.println(value1);
            result.setText(value1.toString() + "%");
            tb.clear();
            
        });
        // Create scene and stage
        Scene scene = new Scene(grid, 300, 150);
        primaryStage.setTitle("Percent Converter");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
